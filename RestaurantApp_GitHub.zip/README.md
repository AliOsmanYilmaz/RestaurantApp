# 🍽️ RestaurantApp

C# Windows Forms ile geliştirilmiş, MySQL veritabanı destekli restoran sipariş uygulaması.

## 📋 Özellikler

- MySQL veritabanı bağlantısı
- Sipariş oluşturma (içecek, tatlı, yan ürün, ana yemek, çorba)
- Otomatik fiyat hesaplama
- Sipariş listeleme ve silme (DataGridView)
- Sipariş numarası takibi

## 🖥️ Ekranlar

| Ekran | Açıklama |
|-------|----------|
| Form1 | Veritabanı bağlantı ekranı |
| Form2 | Sipariş alma ekranı |
| Form3 | Sipariş yönetim ekranı |

## ⚙️ Kurulum

### Gereksinimler
- Visual Studio 2019+
- .NET Framework 4.7.2
- MySQL Server

### Adımlar

1. Repoyu klonlayın:
   ```bash
   git clone https://github.com/KULLANICI_ADINIZ/RestaurantApp.git
   ```

2. `Form1.cs`, `Form2.cs`, `Form3.cs` içindeki bağlantı satırlarında kendi MySQL bilgilerinizi girin:
   ```csharp
   con = new MySqlConnection("server=localhost;username=KULLANICI;password=SIFRE;");
   ```

3. Visual Studio'da `RestourantApp.sln` dosyasını açın.

4. NuGet paketlerini yükleyin: Sağ tık → **Restore NuGet Packages**

5. Derleyip çalıştırın (F5).

## 📦 Kullanılan Teknolojiler

- C# / Windows Forms (.NET Framework 4.7.2)
- MySQL (MySql.Data 9.6.0)

## 📄 Lisans

MIT License
