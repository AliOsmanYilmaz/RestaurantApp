﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestourantApp
{
    internal class SiparisNo
    {
        public static int no = 0;
    }
}
