﻿using Google.Protobuf;
using Google.Protobuf.Reflection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace RestourantApp
{
    public partial class Form2 : Form
    {
        MySqlConnection con;
        MySqlCommand cmd;

        int fiyat = 0,c1,c2,c3,c4,c5;
        bool isTouched = false;
        public Form2()
        {
            InitializeComponent();
        }


        private void Form2_Load(object sender, EventArgs e)
        {
            isTouched = false;

            comboBox1.Items.Add("");
            comboBox1.Items.Add("Kahve");
            comboBox1.Items.Add("Çay");
            comboBox1.Items.Add("Ayran");
            comboBox1.Items.Add("Şalgam");
            comboBox1.Items.Add("Su");

            comboBox2.Items.Add("");
            comboBox2.Items.Add("Baklava");
            comboBox2.Items.Add("Şekerpare");
            comboBox2.Items.Add("Ekler");
            comboBox2.Items.Add("Tulumba");
            comboBox2.Items.Add("Tiramisu");

            comboBox3.Items.Add("");
            comboBox3.Items.Add("Akdeniz Salata");
            comboBox3.Items.Add("Mevsim Salata");
            comboBox3.Items.Add("Közlenmiş Biber");
            comboBox3.Items.Add("Kaışık Yeşillik");
            comboBox3.Items.Add("Pilav");

            comboBox4.Items.Add("");
            comboBox4.Items.Add("Tantuni");
            comboBox4.Items.Add("Kuru Fasülye");
            comboBox4.Items.Add("Tavuk Pilav");
            comboBox4.Items.Add("Köfte");
            comboBox4.Items.Add("İskender");

            comboBox5.Items.Add("");
            comboBox5.Items.Add("Mercimek");
            comboBox5.Items.Add("Yoğurt");
            comboBox5.Items.Add("Domates");
            comboBox5.Items.Add("Kelle Paça");
            comboBox5.Items.Add("Tel Şehriye");

            //Enter your MySql root and password 
            con = new MySqlConnection("server=localhost;username=;password=;");
            con.Open();

            cmd = new MySqlCommand("Create database if not exists Restaurant;", con);
            cmd.ExecuteNonQuery();

            cmd = new MySqlCommand("Create table if not exists Restaurant.siparisler (id int primary key auto_increment,ad varchar(50),soyad varchar(50),icecek varchar(50), tatli varchar(50), yanurun varchar(50), anayemek varchar(50), corba varchar(50),toplam varchar(50),siparisNo int);", con);
            cmd.ExecuteNonQuery();

            con.Close();

            lbl_siparisNo.Text = SiparisNo.no.ToString();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(comboBox1.SelectedIndex)
            {
                case 1:
                    c1 = 15;
                    break;

                case 2:
                    c1 = 10;
                    break;

                case 3:
                    c1 = 10;
                    break;

                case 4:
                    c1 = 10;
                    break;

                case 5:
                    c1 = 2;
                    break;

                default:
                    c1 = 0;
                    break;
            }
            lbl_icecek.Text = comboBox1.Text;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(comboBox2.SelectedIndex)
            {
                case 1:
                    c2 = 25;
                    break;
                case 2:
                    c2 = 20;
                    break;
                case 3:
                    c2 = 20;
                    break;
                case 4:
                    c2 = 15;
                    break;
                case 5:
                    c2 = 25;
                    break;
                default:
                    c2 = 0;
                    break;
            }
            lbl_tatli.Text = comboBox2.Text;
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(comboBox3.SelectedIndex)
            {
                case 1:
                    c3 = 25;
                    break;
                case 2:
                    c3 = 20;
                    break;
                case 3:
                    c3 = 15;
                    break;
                case 4:
                    c3 = 10;
                    break;
                case 5:
                    c3 = 20;
                    break;
                default:
                    c3 = 0;
                    break;
            }
            lbl_yanurun.Text = comboBox3.Text;
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(comboBox4.SelectedIndex)
            {
                case 1:
                    c4 = 35;
                    break;
                case 2:
                    c4 = 30;
                    break;
                case 3:
                    c4 = 30;
                    break;
                case 4:
                    c4 = 25;
                    break;
                case 5:
                    c4 = 35;
                    break;
                default:
                    c4 = 0;
                    break;
            }
            lbl_anayemek.Text = comboBox4.Text;
        }

        private void groupBox6_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(comboBox5.SelectedIndex)
            {
                case 1:
                    c5 = 10;
                    break;
                case 2:
                    c5 = 10;
                    break;
                case 3:
                    c5 = 15;
                    break;
                case 4:
                    c5 = 20;
                    break;
                case 5:
                    c5 = 15;
                    break;
                default:
                    c5 = 0;
                    break;
            }
            lbl_corba.Text = comboBox5.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            isTouched = true;
            fiyat = c1 + c2 + c3 +c4 + c5;
            lbl_toplam.Text = fiyat.ToString() + "TL";

            if(fiyat == 0)
            {
                button3.Enabled = false;
                isTouched = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Siparişiniz iptal edilecek. Emin misiniz?", "Sipariş İptali", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                comboBox1.SelectedIndex = 0;
                comboBox2.SelectedIndex = 0;
                comboBox3.SelectedIndex = 0;
                comboBox4.SelectedIndex = 0;
                comboBox5.SelectedIndex = 0;
                lbl_toplam.Text = "";
                txt_ad.Text = "";
                txt_soyad.Text = "";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ComboBox[] comboBoxes = { comboBox1, comboBox2, comboBox3, comboBox4, comboBox5 };
            int emptyCount = 0;

            foreach (ComboBox comboBox in comboBoxes)
            {
                if (comboBox.Text == "")
                {
                    emptyCount++;
                }
            }


            if (emptyCount < 5 && !string.IsNullOrEmpty(txt_ad.Text) && !string.IsNullOrEmpty(txt_soyad.Text))
            {
                button3.Enabled = true;
            }

            else
            {
                button3.Enabled = false;
                isTouched = false;
            }



            if (emptyCount < 5 && isTouched && !string.IsNullOrEmpty(txt_ad.Text) && !string.IsNullOrEmpty(txt_soyad.Text))
            {
                if (MessageBox.Show("Siparişiniz Onaylanacak. Emin misiniz?", "Sipariş Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    MessageBox.Show("Siparişiniz Alındı. Afiyet Olsun!\n" + "Ücret : " + fiyat + "TL", "Siparişiniz", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    cmd = new MySqlCommand("insert into Restaurant.siparisler (ad,soyad,icecek, tatli, yanurun, anayemek, corba, toplam, siparisNo) values (@ad, @soyad, @icecek, @tatli, @yanurun, @anayemek, @corba, @toplam, @siparisNo)", con);

                    cmd.Parameters.AddWithValue("@ad", txt_ad.Text);
                    cmd.Parameters.AddWithValue("@soyad", txt_soyad.Text);
                    cmd.Parameters.AddWithValue("@icecek", comboBox1.Text);
                    cmd.Parameters.AddWithValue("@tatli", comboBox2.Text);
                    cmd.Parameters.AddWithValue("@yanurun", comboBox3.Text);
                    cmd.Parameters.AddWithValue("@anayemek", comboBox4.Text);
                    cmd.Parameters.AddWithValue("@corba", comboBox5.Text);
                    cmd.Parameters.AddWithValue("@toplam", fiyat.ToString());
                    cmd.Parameters.AddWithValue("@siparisNo", lbl_siparisNo.Text);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    SiparisNo.no++;
                    lbl_siparisNo.Text = SiparisNo.no.ToString();

                    comboBox1.SelectedIndex = 0;
                    comboBox2.SelectedIndex = 0;
                    comboBox3.SelectedIndex = 0;
                    comboBox4.SelectedIndex = 0;
                    comboBox5.SelectedIndex = 0;
                    lbl_toplam.Text = "";
                    txt_ad.Text = "";
                    txt_soyad.Text = "";
                }
            }

            else
            {
                if (emptyCount == 5)
                {
                    MessageBox.Show("Lütfen en az bir ürün seçiniz.", "Sipariş Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if (!isTouched)
                {
                    MessageBox.Show("Lütfen siparişinizin toplam tutarını hesaplayınız.", "Sipariş Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if (string.IsNullOrEmpty(txt_ad.Text) || string.IsNullOrEmpty(txt_soyad.Text))
                {
                    MessageBox.Show("Lütfen adınızı ve soyadınızı giriniz.", "Sipariş Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        private void button4_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Bu kısmı atlamak istediğinizden emin misiniz?","Onay",MessageBoxButtons.YesNo,MessageBoxIcon.Information)  == DialogResult.Yes)
            {
                this.Hide();
                Form3 form3 = new Form3();
                form3.Show();
            }
        }




    }
}
