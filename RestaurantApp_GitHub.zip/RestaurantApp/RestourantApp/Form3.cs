﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace RestourantApp
{
    public partial class Form3 : Form
    {
        MySqlConnection con;
        DataSet ds;
        DataTable dt;
        MySqlDataAdapter da;
        MySqlCommand cmd;
        string index = "0";

        public Form3()
        {
            InitializeComponent();
        }

        void setData()
        {
            //Enter your MySql root and password 
            con = new MySqlConnection("server=localhost;username=;password=;");
            con.Open();

            dt = new DataTable();
            dt.Clear();

            da = new MySqlDataAdapter("select * from restaurant.siparisler", con);
            ds = new DataSet();
            da.Fill(ds, "siparisler");
            dataGridView1.DataSource = ds.Tables["siparisler"];

            con.Close();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            setData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            setData();
        }

        
        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                if (dataGridView1.SelectedRows[0].IsNewRow)
                {
                    MessageBox.Show("Lütfen bir slot seçiniz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                index = dataGridView1.SelectedRows[0].Cells["id"].Value.ToString();
                cmd = new MySqlCommand("Delete From restaurant.siparisler where id = @id;", con);
                cmd.Parameters.AddWithValue("@id", index);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                setData();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SiparisNo.no = 0;

            cmd = new MySqlCommand("Delete From restaurant.siparisler;", con);
            
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            setData();
        }


        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Sipariş Menüsüne dönmek istediğinize emin misiniz?", "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide();
                Form2 form2 = new Form2();
                form2.Show();
            }
        }

    }
}
