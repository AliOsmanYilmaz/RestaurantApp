﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace RestourantApp
{
    public partial class Form1 : Form
    {
        MySqlConnection con;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Enter your MySql root and password 
            con = new MySqlConnection("server = localhost;= root;password=;");

            if (con.State != ConnectionState.Open)
            {
                con.Open();
                label1.Text = "Connection ✔";
                label1.ForeColor = Color.Green;
                button2.Enabled = true;
                button3.Enabled = true;
                label2.Text = "Şuan sipariş verebilirsiniz!";
                label2.ForeColor = Color.Green;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
                label1.ForeColor = Color.Red;
                label1.Text = "Connection ×";
                button3.Enabled = false;
                label2.Text = "Sipariş vermek için önce sisteme bağlanın lütfen!";
                label2.ForeColor = Color.Red;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form2 = new Form2();
            form2.Show();
            con.Close();
        }
    }
}
